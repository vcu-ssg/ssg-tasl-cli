
import sys
from loguru import logger

# Define custom message templates
#info_template = "<green>{time}</green> - <level>{level}</level> - <cyan>{message}</cyan>"
#success_template = "<green>{time}</green> - <level>{level}</level> - <magenta>{message}</magenta>"
#warning_template = "<green>{time}</green> - <level>{level}</level> - <yellow>{message}</yellow>"

info_template = "<cyan>{message}</cyan>"
success_template = "<magenta>{message}</magenta>"
warning_template = "<level>{level}</level>: <yellow>{message}</yellow>"


# Remove the default handler
logger.remove()

# Add custom handlers for specific log levels, writing to stderr
logger.add(sys.stderr, format=info_template, level="INFO", filter=lambda record: record["level"].name == "INFO")
logger.add(sys.stderr, format=success_template, level="SUCCESS", filter=lambda record: record["level"].name == "SUCCESS")
logger.add(sys.stderr, format=warning_template, level="WARNING", filter=lambda record: record["level"].name == "WARNING")

# Add a default handler for all other log levels, writing to stderr
##logger.add(sys.stderr, format="{time} - {level} - {message}", filter=lambda record: not record["level"].name in ["INFO","SUCCESS","WARNING"])
